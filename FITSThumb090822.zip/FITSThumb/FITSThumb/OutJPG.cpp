#include "OutJPG.hpp"

#include <cstdio>

#include <jpeglib.h> // libjpeg header
#ifdef NDEBUG
#	pragma comment(lib, "jpeg.lib")
#else
#	pragma comment(lib, "jpegd.lib")
#endif

namespace fitmb
{

void
OutJPG(
	const C2DArray<uint8>& image, const char* szFile
){
	std::vector<uint8*> vRows;
	vRows.reserve(image.height());

	// fits �͉������̏��Ɋi�[����Ă���̂�
	// �t���ɏo��
	uint8* pRow = image.ptr() + image.width() * image.height();
	for(int i = image.height(); i > 0; --i){
		pRow -= image.width();
		vRows.push_back(pRow);
	}

	// JPG ����
	jpeg_error_mgr        jerr;
	jpeg_compress_struct  jcom;
	jcom.err = jpeg_std_error(&jerr);
	jpeg_create_compress(&jcom);

	std::FILE* f = std::fopen(szFile, "wb");
	if(! f){
		throw CException("OutJPG: ", szFile, " ���J���Ȃ�");
	}

	jpeg_stdio_dest(&jcom, f);

	jcom.image_width  = image.width();
	jcom.image_height = image.height();
	jcom.input_components = 1; /* �F�� */
	jcom.in_color_space = JCS_GRAYSCALE;
	jpeg_set_defaults(&jcom);

	jpeg_set_quality(&jcom, 80 /*0 - 100*/, true);

	// ���k�J�n
	jpeg_start_compress(&jcom, true);
	jpeg_write_scanlines(
		&jcom, (JSAMPARRAY)&vRows[0], image.height()
	);
	jpeg_finish_compress(&jcom);

	// �I��
	jpeg_destroy_compress(&jcom);
	std::fclose(f);
}

} // namespace fitmb
