#ifndef fitmb_Output_hpp__
#define fitmb_Output_hpp__

#include "2DArray.hpp"
#include "ToUInt8.hpp"
#include "Common.hpp"

namespace fitmb
{

void
Output(
	const C2DArray<uint8>& image,
	const char* szOutType,
	const char* szFile,
	bool bAppendExtension
);

template <class T>
void
Output(
	const C2DArray<T>& image,
	const char* szOutType,
	const char* szFile,
	bool bAppendExtension
){
	Output(*ToUInt8(image), szOutType, szFile, bAppendExtension);
}

} // namespace fitmb

#endif // fitmb_Output_hpp__
