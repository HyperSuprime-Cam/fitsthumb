#ifndef fitmb_OutJPG_hpp__
#define fitmb_OutJPG_hpp__

#include "2DArray.hpp"
#include "ToUInt8.hpp"
#include "Common.hpp"


namespace fitmb
{

void OutJPG(const C2DArray<uint8>& image, const char* szFile);

template <class T>
void OutJPG(const C2DArray<T>& image, const char* szFile)
{
	OutJPG(*ToUInt8(image), szFile);
}

} // namespace fitmb
#endif //fitmb_OutJPG_hpp__
