#!/bin/bash

cd $(dirname $_)

aFiles=(../FITSThumb/*.[hc]pp)

for i in ${aFiles[@]}
do
	echo $i
done
read -p 'Convert files above? [y/N] ' k && test "$k" == "y" || exit 1

for i in ${aFiles[@]}
do
	echo -n converting "$i..."
	mv -f "$i" "$i~"
	nkf -e -S < "$i~" > "$i"
	echo "done"
done
# eof
