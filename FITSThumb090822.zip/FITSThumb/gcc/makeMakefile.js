/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	makeMakefile.js													Sogo Mineo

	creates Makefile for GCC.

	This script runs under Windows Scripting Host (WSH).
	When WSH is installed on your computer,
	just double-click on the icon to execute this script.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

var fso = new ActiveXObject("Scripting.FileSystemObject");

var g_strExeName	= "fitsthumb"
var g_strSrcDir		= "..\\FITSThumb";
var g_regSrcExt		= /\.cpp$/;
var g_strObjExt		= ".o";
var g_strCompile	= "g++ -O3 -Wall"
var g_strLink		= "g++"
var g_strLinkFlag	=  "-O3 -Wall -ljpeg -lpng -lz -lcfitsio"

Main();


////////////////////////////////////////////////////////////////////////////////
// Main Proc
function Main()
{
	var setSrcs		= GetSourcePaths();
	var mapSrcToObj	= GetObjectPaths(setSrcs);

	var fout = fso.CreateTextFile("Makefile", true /*CREATE_ALWAYS*/);

	fout.Write("OBJECTS =");
	for(strSrc in setSrcs){
		fout.Write(" " + mapSrcToObj[strSrc]);
	}

	fout.Write(
		"\nCOMPILE = " + g_strCompile			+
		"\nLINK    = " + g_strLink				+
		"\nLDFLAGS = " + g_strLinkFlag			+
		"\n\n" + g_strExeName + " : $(OBJECTS)"	+
		"\n\t$(LINK) $(OBJECTS) $(LDFLAGS) -o $@\n\n"
	);

	for(strSrc in setSrcs){
		fout.Write(mapSrcToObj[strSrc] + " : " + strSrc.replace(/\\/g, "/"));
		for(strHdr in GetHeaders(strSrc)){
			fout.Write(" " + strHdr.replace(/\\/g, "/"));
		}
		fout.Write("\n\t$(COMPILE) -c " + strSrc.replace(/\\/g, "/") + " -o $@\n");
	}

	fout.Close();
}


////////////////////////////////////////////////////////////////////////////////
// returns set of source paths
function GetSourcePaths()
{
	var setstr = {};

	for(var it = new Enumerator(fso.GetFolder(g_strSrcDir).Files);
		! it.atEnd(); it.moveNext() )
	{
		var str = it.item().Name;
		if(g_regSrcExt.test(str)){
			setstr[fso.BuildPath(g_strSrcDir, str)] = null;
		}
	}

	return setstr;
}


////////////////////////////////////////////////////////////////////////////////
// returns map of source paths to object paths
function GetObjectPaths(setstrSrcs)
{
	var map = {};

	for(strSrc in setstrSrcs){
		map[strSrc] = fso.GetFileName(strSrc).replace(/\.[^\.]*$/, g_strObjExt);
	}

	return map;
}


////////////////////////////////////////////////////////////////////////////////
// returns set of header paths included in strSrc in/directly
function GetHeaders(strSrc)
{
	return GetHeaders_helper(strSrc, {});
}


////////////////////////////////////////////////////////////////////////////////
// returns setstrHeaders that is enhanced
function GetHeaders_helper(strSrc, setstrHeaders)
{
	var strDir = fso.GetParentFolderName(strSrc);

	var fin = fso.OpenTextFile(strSrc);
		var strAll = fin.ReadAll();
	fin.Close();

	// process line feeds
	strAll = strAll.replace(/\r\n?/g, "\n");

	// process comments
	strAll = strAll.replace(
		/(?:"(?:\\.|[^"\n\\])*["\n])|(?:'(?:\\.|[^'\n\\])*['\n])|\/\*(?:.|\n)*?\*\/|\/\/.*?\n/g, //"
		function($0)
		{
			switch($0.substr(0, 2)){
			case "/*":
				return " ";
			case "//":
				return "\n";
			default:
				return $0;
			}
		}
	);

	// extract #includes
	var astr = strAll.match(/[ \t]*#[ \t]*include[ \t]*".+?"/g);
	if(astr != null){
		// enhance setstrHeaders and recur
		for(var i = 0; i < astr.length; ++i){
			astr[i].search(/"(.+?)"/);

			var strHeader = fso.BuildPath(strDir, RegExp.$1);
			if(setstrHeaders[strHeader] == undefined){
				setstrHeaders[strHeader] = null;
				setstrHeaders = GetHeaders_helper(strHeader, setstrHeaders);
			}
		}
	}

	return setstrHeaders;
}


// eof : makeMakefile.js
